---
uis-id: UIS-ORD-008
name: shop
domain: order
domain-code: ORD
layer: ui
screen-id: shop
route: /shop
screens_role: 주화면
api_hints:
  - "GET /api/products"
  - "GET /api/cart"
  - "POST /api/members/sessions/logout"
  - "GET /images/products/{파일}"
access_control: []
anchors:
  - "modules/shop-web/src/App.tsx:93"
  - "src/pages/ShopHomePage.tsx"
  - "src/features/shop/Gnb.tsx"
  - "src/features/shop/RankingSection.tsx"
  - "src/features/shop/AppShell.tsx"
  - "src/features/shop/QuickBar.tsx"
  - "src/features/shop/RightRail.tsx"
  - "shop-api:src/main/java/com/sm/lab/shop/controller/ShopIndexController.java"
revision_history:
  - "2026-09-17 골격 생성(spec_resync_check, zero-LLM)"
  - "2026-09-22 SOP급 보강(ddd-ui-agent, source-authority) — DOM 스냅샷·스크린샷(대표+랭킹탭 3종) 반영, §0/§2 시나리오/§4 위젯표/§6 팝업/스토리 링크 추가"
---

# UIS-ORD-008: shop

> [반영: SR-302.1] — 코드(라우트) 기준 재동기화 골격. 화면 구성·상태·검증 규칙은 보강 대상
>
> **근거 소스(권위):** `apps/shop-web/src/pages/ShopHomePage.tsx` 및 `features/shop/*.tsx`
> (Gnb·GnbTabs·AppShell·QuickBar·RightRail·HeroBannerCarousel·CategoryShortcuts·ProductGrid·
> ProductCard·RankingSection·RecentlyViewed·ShopFooter·QrPopup) + `ShopIndexController.java`.
> 스크린샷(대표 1장 + 랭킹 탭 2장)·DOM 스냅샷은 시각 자료·위젯 골격의 보조 근거.

## 0. 화면 미리보기

![개요](preview_annotated.png)

> 원 안 번호 = 아래 「4. 위젯·액션」 소제목 번호와 1:1 대응.
>
> | 마커 | 블록 |
> |---|------|
> | ① | GNB(로고·카테고리·검색·장바구니·로그인) |
> | ② | GNB 탭(홈) |
> | ③ | 좌측 퀵바(≥1200px 전용) |
> | ④ | 히어로 배너 |
> | ⑤ | 카테고리 숏컷 |
> | ⑥ | 추천 상품 그리드 |
> | ⑦ | 랭킹(탭 전환 — 인기/가격) |
> | ⑧ | 최근 본 상품 |
> | ⑨ | 우측 레일(≥1200px 전용) |
>
> 랭킹(⑦)은 화면 내 상태 전환(탭)이라 별도 캡처 3종(홈 진입 초기값=인기, 인기탭 강조, 가격탭
> 전환)을 「4.7 랭킹」에 함께 싣는다.

## 1. 화면 목적

커머스 앱의 **비로그인 진입 가능 홈(메인)** 화면이다(SR-302, SR-307). 로그인 여부와 무관하게
`/shop`(서버) → `#/shop`(SPA 해시라우트) 1회 리다이렉트로 도달하며, GNB·배너·카테고리 숏컷·
추천 상품·랭킹·최근 본 상품·앱 셸(퀵바/레일/하단탭바)을 통해 상품 탐색과 다른 화면(상품 목록·
장바구니·로그인·마이페이지) 진입의 허브 역할을 한다. 화면 자체는 읽기 전용 — 수량·금액 입력은
없다.

## 2. 주요 작업 시나리오

**시나리오 A: 상품을 검색해 상품 목록으로 이동**
1. GNB 검색 입력(④番 아님, ①-4)에 검색어를 입력한다.
2. Enter 제출 또는 검색 아이콘(🔍) 클릭 — `handleSearchSubmit()`(`ShopHomePage.tsx:84-87`)이
   검색어를 `?keyword=`로 실어 `/shop/products`(상품 목록 화면, UIS-ORD-009)로 `navigate`한다.
3. 검색어가 비어 있으면 쿼리 없이 이동(목록 화면이 전체 목록을 보여준다).
4. (아이콘 클릭 특수 케이스, `Gnb.tsx:66-84`) 이미 상품 목록 화면 안에서 빈 검색어로 아이콘을
   누르면 같은 `onSearchSubmit`을 재사용해 URL·표시 상태를 맞춘다. 목록 화면 밖에서 빈 검색어로
   누르면 `navigate('/shop/products', { state: { focusSearch: true } })`로 이동만 하고, 도착
   화면이 `autoFocusSearch`를 내려줄 때만 검색 입력에 포커스가 잡힌다(자기 자신은 포커스하지
   않음 — 언마운트 경합 회피).

**시나리오 B: 카테고리 숏컷으로 상품 목록 진입**
1. 카테고리 아이콘(패션/뷰티/리빙/디지털/식품/스포츠 중 하나) 클릭.
2. `handleCategorySelect()`(`ShopHomePage.tsx:92-94`)가 파라미터 없이 `/shop/products`로 이동 —
   카테고리 필터 API가 없어(범위 밖, scope_freeze) 라벨을 검색어로 대체하지 않는다(round1에서
   시도했으나 시드 상품명과 라벨이 겹치지 않아 항상 빈 결과였던 결함을 round2에서 되돌림).

**시나리오 C: 상품 카드 선택 → 최근 본 상품 갱신**
1. 추천 상품 그리드·랭킹·최근 본 상품 중 어느 카드든 클릭(`onSelect` prop, `ProductCard.tsx`).
2. `handleSelect(sku)`(`ShopHomePage.tsx:77-80`)가 `recordViewed(sku)`로 브라우저 저장소에
   기록하고(`recentlyViewedStorage.ts`, 중복 제거 + 최대 8개 유지), 최근 본 상품 섹션을
   즉시 갱신한다.
3. (카드 클릭 후 상세 화면 이동은 이 STORY 범위 밖 — `onSelect`는 기록만 하고 라우팅은 하지
   않는다. 실제 이동은 각 카드 컴포넌트 상위의 별도 라우트/화면 몫.)

**시나리오 D: 랭킹 기준 전환(인기 ↔ 가격)**
1. 랭킹 섹션의 [인기]/[가격] 탭(`role="tab"`, `RankingSection.tsx:36-46`) 클릭.
2. 인페이지 `useState` 전환일 뿐 API 재호출은 없다 — 이미 로드된 `products`(1회 조회 공유,
   `ShopHomePage.tsx:52`)를 클라이언트에서 재정렬한다.
   - 인기: 응답 순서 그대로 상위 5개(`RANKING_ITEM_COUNT=5`).
   - 가격: `sortByPriceAscending()`로 오름차순 정렬 후 상위 5개.
3. 순위 숫자(1~5)는 `aria-hidden` 없이 그대로 노출한다(스크린리더 접근성 반영, round1 QA 권고).

**시나리오 E: 로그인 상태 확인 및 로그아웃**
1. 세션이 있으면 GNB 우측에 회원명 + [로그아웃] 버튼 + 마이페이지 링크 노출, 없으면 [로그인]
   링크만 노출(`Gnb.tsx:118-133`).
2. [로그아웃] 클릭 시 `handleLogout()`(`ShopHomePage.tsx:100-108`)이 먼저
   POST [INF-MBR-004](../../../member/INF/INF-MBR-004.md)으로 서버 토큰을 폐기하고, 그 호출이 실패해도(네트워크
   오류·5xx) 로컬 세션(`clearSession()`)은 반드시 정리한다 — 로그아웃 자체가 네트워크 장애로
   막히지 않게 하려는 보안 보완(round1 QA 권고 2).

**시나리오 F: 장바구니 수량 확인**
1. 세션이 있을 때만(`session?.memberId`) `GET [INF-ORD-011](../../INF/INF-ORD-011.md)?memberId=`를 호출해 담긴 수량을 배지로
   표시한다(`ShopHomePage.tsx:68-75`, `fetchCartItemCount`).
2. 비로그인이면 호출 자체를 생략하고 0으로 고정 표시. 조회 실패도 조용히 0으로 둔다(배지 하나
   때문에 화면 전체를 오류로 만들지 않음).
3. 🛒 아이콘 클릭 시 `#/shop/cart`(장바구니 화면)로 이동.

**시나리오 G: QR 코드로 현재 화면 공유(좌측 퀵바, ≥1200px)**
1. 퀵바의 [QR] 버튼 클릭 → `QrPopup`(BottomSheet)이 뜨고 `window.location.href`(현재 해시 경로
   포함) 값으로 QR 코드를 로컬 렌더(`qrcode.react`, 외부 API 호출 없음).
2. [TOP] 버튼은 `window.scrollTo({top:0, behavior:'smooth'})`로 스크롤만 수행.

## 3. 화면 구성 (블록)

> 마커 번호 = 「0. 화면 미리보기」의 파란 번호 = 아래 「4. 위젯·액션」 소제목 번호(3중 일치).

| 마커 | 블록 | 역할 | 주요 위젯 | 소스 근거 |
|---|------|------|----------|----------|
| ① | GNB | 로고·카테고리 트리거·검색·장바구니·로그인/로그아웃 | 검색 입력, 검색 아이콘, 🛒 링크, 로그인/로그아웃 | `Gnb.tsx` |
| ② | GNB 탭 | 가로 탭(구현된 것만 노출, 현재 '홈'만) | `Tabs`(공통 컴포넌트) | `GnbTabs.tsx`, `shopStatic.ts:51-61` |
| ③ | 좌측 퀵바 | ≥1200px 전용 — 홈/마이/QR/TOP | 4개 버튼 | `QuickBar.tsx` |
| ④ | 히어로 배너 | 자동 넘김(5초)·좌우 이동·인디케이터 | 이전/다음 버튼, 인디케이터 3개 | `HeroBannerCarousel.tsx` |
| ⑤ | 카테고리 숏컷 | 아이콘+라벨 6개(정적, 클릭 시 목록 이동) | 카테고리 div×6 | `CategoryShortcuts.tsx`, `shopStatic.ts:24-31` |
| ⑥ | 추천 상품 그리드 | 로딩/빈목록/조회실패+재시도/목록(최대 8개) | 상품 카드 | `ProductGrid.tsx`, `ProductCard.tsx` |
| ⑦ | 랭킹 | 인기/가격 탭 전환, 상위 5개 + 순위 숫자 | 탭 2개, 카드×5 | `RankingSection.tsx` |
| ⑧ | 최근 본 상품 | localStorage 8개 이력, 판매종료 시 조용히 제외 | 카드 목록 | `RecentlyViewed.tsx`, `recentlyViewedStorage.ts` |
| ⑨ | 우측 레일 | ≥1200px 전용 — 최근 본 상품 카드(최대 3) + 보유쿠폰/주문건수(현재 미사용) | `aside` | `RightRail.tsx` |
| — | 하단 탭바 | <750px 전용(모바일) — ⑨와 동일 항목을 하단 고정 배치 | — | `BottomTabBar.tsx`(이번 캡처는 데스크톱 폭이라 비노출) |
| — | 푸터 | 사업자 정보·고객센터·약관(정적) | — | `ShopFooter.tsx` |

> 레이아웃은 반응형 3단(`AppShell.tsx:74-99`): **≥1200px** 퀵바+750px 본문+레일 3열 그리드,
> **750~1199px** 본문만(퀵바/레일 숨김), **<750px** 전폭 본문 + 하단 탭바. 이번 캡처(1920px)는
> 데스크톱 3열 상태 — ③·⑨가 노출되고 하단 탭바는 없다.

## 4. 위젯·액션

> 번호 = 「0. 화면 미리보기」 마커 번호와 1:1. 연결 API(raw)는 백틱 없이 평문 기재.

### ① GNB(로고·카테고리·검색·장바구니·로그인)

![① GNB](blocks/block_01.png)

| 위젯 | 타입 | 레이블 | 동작 | 연결 API(raw) | 결과 |
|---|------|--------|------|--------------|------|
| 로고 | a | SL Shop | `href="#/shop"` | — | 홈 재진입 |
| 카테고리 | button | 카테고리 | `aria-haspopup` — 실제 드롭다운 메뉴는 범위 밖(정적) | — | 클릭해도 동작 없음 |
| 검색 입력 | input(search) | 상품 검색 | 제어 입력(controlled), `onChange` | — | `searchValue` state 갱신 |
| 검색 아이콘 | button | 검색 화면으로 이동 | 검색어 있으면 제출과 동일 채널 호출, 없으면 이동/포커스 신호 | — | `/shop/products`(UIS-ORD-009) 이동 |
| (폼 제출, Enter) | form | — | `onSubmit` → `handleSearchSubmit()` | — | `/shop/products?keyword=`(값 있을 때만) 이동 |
| 장바구니 링크 | a | 장바구니 N개 | `href="#/shop/cart"`, N=`cartItemCount` | GET [INF-ORD-011](../../INF/INF-ORD-011.md) (표시용, 세션 있을 때만) | 장바구니 화면 이동 |
| 로그인/로그아웃 | a / button | 로그인 또는 [회원명]님+로그아웃 | 세션 유무로 분기 | POST [INF-MBR-004](../../../member/INF/INF-MBR-004.md)(로그아웃 클릭 시) | 로그인: `#/login` 이동. 로그아웃: 세션 정리 |
| 마이페이지 링크(로그인 시만) | a | 마이페이지 › 배송지 관리 | `href="#/shop/mypage/addresses"` | — | 배송지 관리 화면 이동 |

### ② GNB 탭(홈)

![② GNB 탭](blocks/block_02.png)

| 위젯 | 타입 | 레이블 | 동작 | 연결 API(raw) | 결과 |
|---|------|--------|------|--------------|------|
| 홈 탭 | button(role=tab) | 홈 | 현재 유일하게 `implemented:true`인 탭 — 클릭 시 `/shop`으로 navigate(이미 홈이라 사실상 무동작) | — | — |

> `GNB_TAB_CONFIG`(`shopStatic.ts:51-61`)에 편성표·TV쇼핑·특가쇼·주말엔보너스·브랜드관·랭킹·
> VIP라운지·혜택/이벤트 8개가 더 정의돼 있으나 `implemented:false`(도착 화면 없음)라 GNB에서
> 숨겨진다 — 소스에는 있지만 화면엔 안 보이는 게이팅 사례.

### ③ 좌측 퀵바(≥1200px 전용)

![③ 좌측 퀵바](blocks/block_03.png)

| 위젯 | 타입 | 레이블 | 동작 | 연결 API(raw) | 결과 |
|---|------|--------|------|--------------|------|
| 🏠홈 | button | 홈 | `navigate('/shop')` | — | 홈 재진입 |
| 👤마이 | button | 마이 | 세션 있으면 배송지 관리, 없으면 `redirect=` 쿼리를 실은 로그인 이동 | — | `#/shop/mypage/addresses` 또는 `#/login?redirect=...` |
| ⬜QR | button | QR | `setQrOpen(true)` | — | QrPopup(BottomSheet) 오픈 — 현재 URL의 QR코드 렌더(외부 API 없음) |
| ⬆TOP | button | TOP | `window.scrollTo` | — | 스크롤 최상단 |

> `QUICK_NAV_ITEMS`(`shopStatic.ts:72-77`)의 ON AIR·카테고리는 `implemented:false`라 숨김
> (SR-319·SR-237 전까지). 하단 탭바(`BottomTabBar.tsx`, <750px)가 동일 항목을 재사용한다.

### ④ 히어로 배너

![④ 히어로 배너](blocks/block_04.png)

| 위젯 | 타입 | 레이블 | 동작 | 연결 API(raw) | 결과 |
|---|------|--------|------|--------------|------|
| 이전 배너 | button | 이전 배너 | `goPrev()` | — | 이전 슬라이드 |
| 다음 배너 | button | 다음 배너 | `goNext()` | — | 다음 슬라이드 |
| 배너 N번으로 이동(인디케이터, 3개) | button | 배너 1/2/3번으로 이동 | `setIndex(i)` | — | 해당 슬라이드로 즉시 전환 |
| (자동 넘김) | — | — | 5초(`AUTO_ADVANCE_MS`)마다 자동 전환, `useEffect`+`clearInterval` cleanup | — | — |

> 슬라이드 데이터는 정적(`BANNER_SLIDES`, `shopStatic.ts:18-22`) — 실제 이미지 자산·운영 도구
> 없이 색 배경 + 제목/부제로 대신한다(확정 답변, scope_freeze).

### ⑤ 카테고리 숏컷

![⑤ 카테고리 숏컷](blocks/block_05.png)

| 위젯 | 타입 | 레이블 | 동작 | 연결 API(raw) | 결과 |
|---|------|--------|------|--------------|------|
| 패션/뷰티/리빙/디지털/식품/스포츠(각 1개, 총 6개) | div(role=button) | 아이콘+라벨 | `onClick` → `handleCategorySelect()` | — | `/shop/products`(파라미터 없이 전체 목록) 이동 |

> 카테고리 데이터·필터 API 자체가 없다(`PRODUCTS`에 카테고리 컬럼 없음, 범위 밖) — 클릭해도
> 어느 카테고리를 눌렀는지는 서버로 전달되지 않는다(라벨 무시).

### ⑥ 추천 상품 그리드

![⑥ 추천 상품 그리드](blocks/block_06.png)

| 위젯 | 타입 | 레이블 | 동작 | 연결 API(raw) | 결과 |
|---|------|--------|------|--------------|------|
| 상품 카드(최대 8개, `PRODUCT_GRID_DISPLAY_COUNT`, `ProductCardV2 variant="grid"`) | div(role=button) | 상품명+가격+할인율(있으면) | `onSelect(sku)` | GET [INF-ORD-008](../../INF/INF-ORD-008.md)(최초 1회, 화면 전체 공유) | `recordViewed` — 최근 본 상품 갱신 |
| [다시 시도] | button | 다시 시도 | 조회 실패 시만 노출, `onRetry` | GET [INF-ORD-008](../../INF/INF-ORD-008.md)(재호출) | `inFlightRef` 가드로 연타해도 요청 1회만 |

### ⑦ 랭킹(탭 전환 — 인기/가격)

![홈 진입 시(인기 기본)](tabs/ranking_home_annotated.png)
![인기 탭](tabs/ranking_tab2_인기_annotated.png)
![가격 탭 전환](tabs/ranking_tab3_가격_annotated.png)

| 번호 | 위젯 | 타입 | 레이블 | 동작 | 연결 API(raw) | 결과 |
|---|------|------|--------|------|--------------|------|
| 23 | 인기 탭 | button(role=tab) | 인기 | `setTab('popular')` — 홈 진입 시 기본 활성 | — | 응답 순서 그대로 상위 5개 |
| 24 | 가격 탭 | button(role=tab) | 가격 | `setTab('price')` | — | 가격 오름차순 정렬 상위 5개(캡처 실측: 기계식 키보드 129,000원 → 스탠딩 데스크 390,000원 → 4K 모니터 450,000원 순으로 재배열 확인) |
| 25~27 | 랭킹 카드(순위 1~5, 캡처엔 상위 3개만 노출, `ProductCardV2 variant="ranking"` + `rank`) | div(role=button) | 순위 배지(카드 좌상단, `aria-hidden` 없이 숫자 노출)+상품명/가격 | `onSelect(sku)` | — | 최근 본 상품 갱신(⑥과 같은 `ProductCardV2` 컴포넌트, variant만 다름 — SR-312 #2) |

> 인기/가격 전환은 **API 재호출 없이** 이미 로드된 목록을 클라이언트에서 재정렬만 한다
> (`RankingSection.tsx:29-31`) — DOM 스냅샷 비교로 실측 확인(가격 탭에서 25/26번 카드 위치가
> 뒤바뀜, 위 이미지 참조). 빈 목록이면 "표시할 상품이 없습니다" 문구로 대체.
> 순위 숫자는 round1까지 카드 바깥 `<span>`이었으나(SR-312 #2), 카드 안 순위 배지(`ProductCardV2`
> 좌상단 칩)로 흡수됐다 — `aria-hidden` 없이 텍스트로 노출해 보조기술 접근성은 그대로 유지한다.

### ⑧ 최근 본 상품

![⑧ 최근 본 상품](blocks/block_08.png)

| 위젯 | 타입 | 레이블 | 동작 | 연결 API(raw) | 결과 |
|---|------|--------|------|--------------|------|
| 상품 카드(있을 때만, 최대 8개) | div(role=button) | 상품명+가격 | `onSelect` 없음(이 섹션 카드는 클릭 이벤트 미배선 — `RecentlyViewed.tsx:23`에 `onSelect` prop 전달 안 함) | — | — |
| 빈 상태 문구 | — | 최근 본 상품이 없습니다 | `recentlyViewedProducts.length===0`일 때 | — | — |

> 브라우저 저장(`recentlyViewedStorage.ts`) 기반 — 서버 API 없음. 판매 종료(현재 목록에 없는
> sku)는 조용히 제외한다(없음을 지어내지 않음).

### ⑨ 우측 레일(≥1200px 전용)

![⑨ 우측 레일](blocks/block_09.png)

| 위젯 | 타입 | 레이블 | 동작 | 연결 API(raw) | 결과 |
|---|------|--------|------|--------------|------|
| (최근 본 상품 카드, 있을 때만) | aside 내부 div | 상품명(최대 3개) | 클릭 이벤트 없음(표시 전용) | GET [INF-ORD-008](../../INF/INF-ORD-008.md)(레일 자체가 별도 1회 재호출 — `RightRail.tsx:48-59`) | — |
| (보유 쿠폰/주문 내역 카드, 현재 항상 숨김) | aside 내부 div | 보유 쿠폰 N장 · 주문 내역 N건 | `entitlementCounts` prop을 아무도 채우지 않아(SR-276 이후 과제) 항상 미노출 | — | — |

> 이번 캡처는 최근 본 상품이 0개라 레일 콘텐츠가 없다(`recentProducts.length===0 && !showEntitlement`
> → `null` 반환, `RightRail.tsx:70`) — DOM엔 `appshell-rail-slot` 빈 컨테이너만 남는다(마커 ⑨는
> 그 빈 슬롯). **레일은 홈 본문과 별개로 GET [INF-ORD-008](../../INF/INF-ORD-008.md)를 1회 더 호출한다**(최근 본 sku가
> 1개 이상일 때만) — 화면 전체가 API 1회만 공유한다는 §1 원칙의 예외.

## 5. 접근 권한·표시 조건

| 요소 | 표시 조건 | 근거 | 스토리 |
|------|----------|------|--------|
| GNB 우측 로그인/로그아웃 영역 | 세션 유무(`session` state) | `Gnb.tsx:118-133` | [비로그인](story:쇼핑홈-gnb--비로그인) / [로그인](story:쇼핑홈-gnb--로그인) |
| 장바구니 수량 배지 | `cartItemCount > 0`일 때만 숫자 노출 | `Gnb.tsx:110-116` | [장바구니담김](story:쇼핑홈-gnb--장바구니담김) |
| 좌측 퀵바 / 우측 레일 / 하단 탭바 | 뷰포트 폭(`useBreakpoint`, ≥1200 / 750~1199 / <750) | `AppShell.tsx:47-48, 74-99` | — |
| 히어로 배너 좌우/인디케이터 | 슬라이드 2개 이상일 때만 노출 | `HeroBannerCarousel.tsx:50` | [여러장](story:쇼핑홈-히어로-배너--여러장) / [한장](story:쇼핑홈-히어로-배너--한장) |
| 추천 상품 — 로딩 | `loading===true` | `ProductGrid.tsx:40` | [로딩](story:쇼핑홈-추천-상품-그리드--로딩) |
| 추천 상품 — 조회 실패 + [다시 시도] | `error` 값 있음 | `ProductGrid.tsx:22-38` | [조회실패](story:쇼핑홈-추천-상품-그리드--조회실패) |
| 추천 상품 — 빈 목록 | `rows.length===0` | `ProductGrid.tsx:42-49` | [빈목록](story:쇼핑홈-추천-상품-그리드--빈목록) |
| 추천 상품 — 목록 있음 | 그 외 | `ProductGrid.tsx:51-56` | [목록있음](story:쇼핑홈-추천-상품-그리드--목록있음) |
| 추천 그리드·랭킹 카드(`ProductCardV2`) — 품절 표시 | `soldOut` prop(`stockQty <= 0`) — 썸네일 blur+grayscale, "품절" 칩 우상단 | `ProductCardV2.tsx:141,169-178`, 호출부 `ProductGrid.tsx:63`/`RankingSection.tsx:65` | [품절](story:공통-상품-카드-v2--품절) |
| 추천 그리드·랭킹 카드(`ProductCardV2`) — 이미지 없음/로드 실패 → 빈 회색 틀 | `!imageUrl \|\| imgLoadFailed`(이니셜 문자 없음 — v1과 의도적으로 다름, `aria-label` 라벨은 유지) | `ProductCardV2.tsx:83, 144-160` | — |
| 추천 그리드·랭킹 카드(`ProductCardV2`) — 이미지 있음 | `imageUrl` 있고 로드 성공 | `ProductCardV2.tsx:130-143` | — |
| 추천 그리드·랭킹 카드(`ProductCardV2`) — 정가 취소선·할인율 | `hasListPriceDiscount(price, listPrice)`(정가 있고 판매가보다 큼) | `ProductCardV2.tsx:87-88, 226-253`, `discountRate.ts`(SR-306 정본 재사용, 계산식 복제 없음) | — |
| 추천 그리드·랭킹 카드(`ProductCardV2`) — 배지 줄·별점·범위가 | 각각 값이 있을 때만 렌더(값 없으면 줄 자체 숨김, 가짜 값 금지) — 이 화면의 실 소비처(ProductGrid·RankingSection)는 현재 원천 데이터를 넘기지 않아 항상 미노출(그릇만 존재, 배선은 후속 SR) | `ProductCardV2.tsx:197-224`, `productCardBadges.ts` | — |
| 랭킹 — 인기/가격 탭 | `tab` state | `RankingSection.tsx:26-31` | [인기탭](story:쇼핑홈-랭킹--인기탭) / [가격탭전환](story:쇼핑홈-랭킹--가격탭전환) |
| 최근 본 상품 카드(v1 `ProductCard`, 미교체) — 있음/없음 | `recentlyViewedProducts.length` | `RecentlyViewed.tsx:17-27, 23` | [있음](story:쇼핑홈-최근-본-상품--있음) / [없음](story:쇼핑홈-최근-본-상품--없음) |
| 카테고리 숏컷 | 항상 노출(정적 데이터, `categories.length` 비어 있으면만 숨김) | `CategoryShortcuts.tsx:15` | [기본](story:쇼핑홈-카테고리-숏컷--기본) |
| 푸터 | 항상 노출(정적) | `ShopFooter.tsx` | [기본](story:쇼핑홈-푸터--기본) |
| GNB 가로 탭 | `GNB_TAB_CONFIG`에서 `implemented && path`인 것만(현재 '홈' 1개) | `GnbTabs.tsx:20-21`, `shopStatic.ts:51-61` | — |
| 이미지없음 | (스토리 `쇼핑홈/상품 카드`의 상태 — 표시 조건은 실물 참조) | stories: ./src/features/shop/ProductCard.stories.tsx | [이미지없음](story:쇼핑홈-상품-카드--이미지없음) |
| 이미지로드실패 | (스토리 `쇼핑홈/상품 카드`의 상태 — 표시 조건은 실물 참조) | stories: ./src/features/shop/ProductCard.stories.tsx | [이미지로드실패](story:쇼핑홈-상품-카드--이미지로드실패) |

## 6. 팝업·연계 화면

| 트리거 위젯 | 팝업/연계 화면 | 연결 API/화면 (raw → INF) | 용도 |
|------------|--------------|--------------------------|------|
| 좌측 퀵바 [QR] | QrPopup(BottomSheet, 페이지 이동 없는 인페이지 팝업) | — (외부 API 호출 없음, `qrcode.react`로 로컬 렌더) | 현재 화면 URL을 QR 코드로 공유 |
| GNB 검색 제출 / 검색 아이콘 | 상품 목록 화면(UIS-ORD-009) | GET /shop/products (화면 이동, INF 없음) | 검색 결과 목록 진입 |
| 카테고리 숏컷(6종) | 상품 목록 화면(UIS-ORD-009) | GET /shop/products (화면 이동, INF 없음) | 카테고리 무시 전체 목록 진입 |
| GNB 🛒 / 좌측 퀵바 없음(레일에는 장바구니 진입 없음) | 장바구니 화면 | GET #/shop/cart (화면 이동, INF 없음) | 장바구니 확인 |
| GNB [로그인] / 퀵바 [마이](비로그인) | 로그인 화면 | GET #/login (화면 이동, INF 없음) | 로그인 |
| GNB 마이페이지 링크 / 퀵바 [마이](로그인 시) | 배송지 관리 화면 | GET #/shop/mypage/addresses (화면 이동, INF 없음) | 배송지 관리 진입 |

> 이 화면 자체가 여는 **모달성 팝업**은 QrPopup 1개뿐이다. 나머지는 전부 라우트 이동(GET 화면
> 진입)이라 INF가 없는 것이 정상이다.

## 7. 데이터 출처·연결

- **연결 API(raw → INF):**
  - GET [INF-ORD-008](../../INF/INF-ORD-008.md) (INF-ORD-008) — 화면 전체(추천 그리드·랭킹·최근 본 상품 필터링)가 이 응답
    하나를 공유. 단, 우측 레일(⑨)은 최근 본 sku가 있을 때만 **별도로 1회 더** 호출한다.
  - GET [INF-ORD-011](../../INF/INF-ORD-011.md) (INF-ORD-011) — 장바구니 수량 배지, 세션 있을 때만.
  - POST [INF-MBR-004](../../../member/INF/INF-MBR-004.md) (INF-MBR-004) — 로그아웃 시 서버 토큰 폐기.
  - GET /images/products/{파일} — 상품 이미지 정적 자산(SR-306), 없으면 이니셜 대체.
- **화면 이동(INF 없음):** GET /shop/products(검색·카테고리), #/shop/cart, #/login,
  #/shop/mypage/addresses.
- **참조 테이블(SCH):** PRODUCTS(카테고리 컬럼 없음 — 범위 밖 근거).

## 8. 미확인 사항

- 추천 상품 그리드·랭킹·최근 본 상품 카드 클릭(`onSelect`) 후 실제로 이동하는 상품 상세 화면의
  UIS-ID(이 STORY 범위 밖 — `recordViewed`만 확정, 라우팅은 카드 상위 호출부가 아직 안 정한
  것으로 보임. 다른 화면(ProductDetailPage 등) 소스 확인 필요).
  - `docs/05_설계서/order/UIS/UIS-ORD-009_*` 등 상품 상세 UIS 문서가 있으면 대조 필요(교차 링크
    보강 대상).
- GNB 카테고리 버튼(①)의 `aria-haspopup="true"`는 있으나 실제 드롭다운 메뉴 구현이 소스에
  없다(정적 트리거만) — 향후 SR로 실제 메뉴가 붙을 자리로 추정.
- 하단 탭바(<750px)는 이번 캡처(1920px 데스크톱)에 나타나지 않아 실측 DOM 스냅샷 없음(소스
  `BottomTabBar.tsx` 기준으로 §3에 기재, 실물 캡처는 추후 모바일 폭 재캡처 권장).

## 변경 이력
<!-- spec-history: machine-managed -->
| 일자 | SR | 항목 | 변경 요약 | 커밋 |
|---|---|---|---|---|
| 2026-09-17 | SR-302 | #1 | 쇼핑 홈(메인) 신규 구현 — GNB·히어로배너·카테고리·추천상품그리드·랭킹·최근본상품·푸터. 진입/라우팅 규칙(round3 확정) 포함 | shop-web@efd0e7c |
| 2026-09-17 | SR-306 | #1 | 상품 카드에 정가 취소선·할인율 배지(정수 연산, 내림)·이미지 대체 영역 표시 규칙 반영 | shop-web@cbe9816 |
| 2026-09-17 | SR-303 | #1 | GNB 검색 제출·카테고리 숏컷 진입 경로를 상품 목록 화면(/shop/products)으로 연결(round1~3 확정, 카테고리는 파라미터 없이 전체 목록) | shop-web@59f2008 |
| 2026-09-22 | SR-302.1 | #2 | SOP급 보강(ddd-ui-agent) — AppShell/QuickBar/RightRail/GnbTabs/QrPopup 등 SR-311 앱 셸 구조 반영, 실캡처(대표+랭킹탭 2종) 기반 §0/§4 마커·표, §2 시나리오 7종, §6 팝업(QrPopup), 스토리 링크(§5) 추가 | (문서 보강, 코드 변경 없음) |
| 2026-09-23 | SR-312 | #2 | 추천 그리드·랭킹 카드를 ProductCardV2(grid/ranking 변형)로 교체 — 순위 배지를 카드 내부로 흡수, 최근 본 상품은 v1 ProductCard 유지(후속 SR) |  |
